#include <stdio.h>
void greet(char* name){
	printf("Bye %s\n",name);
}