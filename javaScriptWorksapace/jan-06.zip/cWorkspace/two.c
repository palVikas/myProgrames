void greet(char*);

int main(int argc, char const *argv[])
{
	greet("World");
	return 0;
}