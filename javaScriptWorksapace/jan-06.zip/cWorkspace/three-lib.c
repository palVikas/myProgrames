#include <stdio.h>
#include "three-lib.h"
void greet(char* name){
	printf("Tata %s\n",name);
}