#include <stdio.h>
void greet(char* name){
	printf("Hello %s\n",name);
}