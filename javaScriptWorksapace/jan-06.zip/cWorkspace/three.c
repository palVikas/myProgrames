#include "three-lib.h"
int main(int argc, char const *argv[])
{
	greet("World");	
	return 0;
}