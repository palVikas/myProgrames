//http://www.gnu.org/software/bash/manual/bash.html#Redirections
console.log('this is log');
console.error('this is error');
console.log('this is also a log');
console.error({status:'hmm'})