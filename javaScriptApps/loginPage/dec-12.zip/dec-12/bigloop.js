for(var i=0;i<100000;i++)
	console.log(i);