var program = require('./program');
console.log(program.run(process.argv.slice(2)));